﻿using iText.Licensing.Base;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Mvc;
using iText;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using System.Xml;

namespace QRCode_App.Controllers
{
    public class ReadPDF : Controller
    {
        private IWebHostEnvironment _hostEnvironment;

        public ReadPDF(IWebHostEnvironment environment)
        {
            _hostEnvironment = environment;
        }
        public IActionResult Index()
        {
            string path = Path.Combine(_hostEnvironment.WebRootPath, "f91a2040e6148c7e0477b072d455561041db5e8165601b39cda0a37a5b0f6b73.json");
            // Make sure to load license file before invoking any code
            LicenseKey.LoadLicenseFile(new FileInfo(path));


            // Parse template into an object that will be used later on
            //  Template template = Pdf2DataExtractor.ParseTemplateFromPDF(Path.Combine(_hostEnvironment.WebRootPath, "Batch1.pdf"));

            // Create an instance of Pdf2DataExtractor for the parsed template
            //  Pdf2DataExtractor extractor = new Pdf2DataExtractor(template);

            // Feed file to be parsed against the template. Can be called multiple times for different files
            //  ParsingResult result = extractor.Recognize(pathToFileToParse);

            // Save result to XML or explore the ParsingResult object to fetch information programmatically
            //    result.SaveToXML(pathToOutXmlFile);
            string result = "";
            string xmlfilepath = Path.Combine(_hostEnvironment.WebRootPath, "Batch.xml");
            XmlDocument document = new XmlDocument();


            //   document.LoadXml(xmlfilepath);

            //  result =   document.FirstChild.FirstChild.Value;

            using (XmlReader reader = XmlReader.Create(xmlfilepath))
            {

                while (reader.Read())
                {
                    if (reader.IsStartElement())
                    {

                        result = result + reader.ReadString() + "\n\n";
                       // reader.ReadEndElement();
                       // reader.MoveToElement();
                        //result = result + reader.ReadString() + "\n\n";

                        //switch (reader.LocalName.Name.ToString())
                        //{
                        //    case "text":
                        //        result = result + reader.ReadString() + "\n\n";
                        //        break;
                        //}

                    }

                    // reader.ReadStartElement();
                    //    reader.MoveToElement();
                    // reader.MoveToAttribute(1);

                    //return only when you have START tag  



                    //    }
                }



                ViewBag.result = result;
            }
            return View();
        }
    }
}
