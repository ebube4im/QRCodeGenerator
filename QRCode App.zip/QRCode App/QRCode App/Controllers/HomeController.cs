﻿using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using QRCode_App.Models;
using QRCoder;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using System.Xml;

namespace QRCode_App.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;
        private IWebHostEnvironment _hostEnvironment;
         
        public HomeController(ILogger<HomeController> logger, IWebHostEnvironment environment)
        {
            _logger = logger;
            _hostEnvironment = environment;
        }


        //public IActionResult Index()
        //{
        //    return View(RedirectToAction("Index"));
        //}

      
        public IActionResult Index()
        {

         
            string xmlfilepath = Path.Combine(_hostEnvironment.WebRootPath, "Batch.xml");
            //  XmlDocument document = new XmlDocument();


            //   document.LoadXml(xmlfilepath);

            //  result =   document.FirstChild.FirstChild.Value;
            List<string> QRCodes = new List<string>() { };

            using (XmlReader reader = XmlReader.Create(xmlfilepath))
            {

                while (reader.Read())
                {
                    if (reader.IsStartElement())
                    {
                        QRCodes.Add(reader.ReadString());
                        // result = result + reader.ReadString() + "\n\n";
                        // reader.ReadEndElement();
                        // reader.MoveToElement();
                        //result = result + reader.ReadString() + "\n\n";

                        //switch (reader.LocalName.Name.ToString())
                        //{
                        //    case "text":
                        //        result = result + reader.ReadString() + "\n\n";
                        //        break;
                        //}

                    }
                }

            }      

                    ImageModel image = new ImageModel() { ImageByteList = new List<string>() };

            // string[] texts = new string[5] { "Ebube", "Makuo", "Buchi", "Amara", "Neme" };

           // QRCodes.Remove("");

            foreach (string item in QRCodes)
            {
                QRCodeGenerator _qrCode = new QRCodeGenerator();
                QRCodeData _qrCodeData = _qrCode.CreateQrCode(item, QRCodeGenerator.ECCLevel.Q);
                QRCode qrCode = new QRCode(_qrCodeData);
                Bitmap qrCodeImage = qrCode.GetGraphic(20);
                image.ImageString = Convert.ToBase64String(BitmapToBytesCode(qrCodeImage));

                image.ImageByteList.Add(image.ImageString);
               // image.ImageByteList.Add(byteitem);

              //  ImageModel newImage = new ImageModel();
              ////  byteitem.CopyTo(Convert.ToBase64CharArray(newImage.ByteModel),0);
              ////  newImage.ByteModel = byteitem;
              //  image.ImageByteList.Add(newImage);

              //  ArrayList buffer = new ArrayList();
              //  // buffer.Add(data);
              //  //byte[] b = (byte[])buffer[0];
    
              

              //  buffer.Add(byteitem);
              //  //  byte[] data = new byte[byteitem.GetLongLength(0)];

              //  //    for (long i = 0; i <= data.GetUpperBound(0); i++) byteitem.CopyTo(data,i);
              //  ////  byteitem.CopyTo(data,);

              //  // 12317;
              //  //Byte[] newitem = new Byte[BitmapToBytesCode(qrCodeImage).Length];

              //  buffer.CopyTo(image.ImageByteList.ToArray());
              ////  image.ImageByteList.;



            }




            






            return View(image);







        }

        [NonAction]
        private static Byte[] BitmapToBytesCode(Bitmap image)
        {
            using (MemoryStream stream = new MemoryStream())
            {
                image.Save(stream, System.Drawing.Imaging.ImageFormat.Png);
                return stream.ToArray();
            }
        }

        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
