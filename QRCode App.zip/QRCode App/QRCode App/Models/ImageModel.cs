﻿using System;

using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace QRCode_App.Models
{
    public class ImageModel
    {
        public Byte[] ByteModel { get; set; }
        public  List<string> ImageByteList { get; set; }

        public string ImageString { get; set; }
    }
}
